# ParkIt
Users can book a parking spot at his/her desired time and can avail the services provided at that parking station.
